<template>
  <ArtTableFullScreen>
    <div class="personal-records-page">
      <!-- 页面标题和统计信息 -->
      <div class="page-header">
        <div class="header-content">
          <h2 class="page-title">我的借阅记录</h2>
          <div class="stats-cards">
            <div class="stat-card">
              <div class="stat-number">{{ borrowRecords.length }}</div>
              <div class="stat-label">总借阅数</div>
            </div>
            <div class="stat-card">
              <div class="stat-number">{{ borrowingCount }}</div>
              <div class="stat-label">借阅中</div>
            </div>
            <div class="stat-card">
              <div class="stat-number">{{ overdueCount }}</div>
              <div class="stat-label">已逾期</div>
            </div>
          </div>
        </div>
      </div>

      <!-- 筛选器 -->
      <ElCard shadow="never" class="filter-card">
        <div class="filter-row">
          <ElSelect
            v-model="statusFilter"
            placeholder="选择状态"
            clearable
            style="width: 200px"
            @change="filterRecords"
          >
            <ElOption label="全部" value="" />
            <ElOption label="借阅中" value="borrowing" />
            <ElOption label="已归还" value="returned" />
            <ElOption label="已逾期" value="overdue" />
          </ElSelect>

          <ElInput
            v-model="searchKeyword"
            placeholder="搜索图书名称"
            clearable
            style="width: 300px"
            prefix-icon="Search"
            @input="filterRecords"
          />
        </div>
      </ElCard>

      <!-- 借阅记录表格 -->
      <ElCard shadow="never" class="table-card">
        <ElTable
          v-loading="loading"
          :data="filteredRecords"
          stripe
          style="width: 100%"
          :empty-text="loading ? '加载中...' : '暂无借阅记录'"
        >
          <!-- 图书信息列 -->
          <ElTableColumn label="图书信息" min-width="300">
            <template #default="{ row }">
              <div class="book-info">
                <img
                  :src="row.bookCover || '/default-book-cover.jpg'"
                  :alt="row.bookTitle"
                  class="book-cover"
                  @error="handleImageError"
                />
                <div class="book-details">
                  <div class="book-title">{{ row.bookTitle }}</div>
                  <div class="book-meta">
                    <span class="author">{{ row.bookAuthor }}</span>
                    <span class="divider">•</span>
                    <span class="publisher">{{ row.bookPublisher }}</span>
                  </div>
                  <div class="book-category">{{ row.bookCategory }}</div>
                </div>
              </div>
            </template>
          </ElTableColumn>

          <!-- 借阅信息列 -->
          <ElTableColumn label="借阅信息" min-width="200">
            <template #default="{ row }">
              <div class="borrow-info">
                <div class="info-row">
                  <span class="label">借阅日期:</span>
                  <span class="value">{{ formatDate(row.borrowDate) }}</span>
                </div>
                <div class="info-row" v-if="row.returnDate">
                  <span class="label">应还日期:</span>
                  <span class="value">{{ formatDate(row.returnDate) }}</span>
                </div>
                <div class="info-row" v-if="row.actualReturnDate">
                  <span class="label">归还日期:</span>
                  <span class="value">{{ formatDate(row.actualReturnDate) }}</span>
                </div>
              </div>
            </template>
          </ElTableColumn>

          <!-- 状态列 -->
          <ElTableColumn label="状态" width="120" align="center">
            <template #default="{ row }">
              <ElTag :type="getStatusTagType(row)" size="large">
                <i :class="getStatusIcon(row)"></i>
                {{ getStatusText(row) }}
              </ElTag>
            </template>
          </ElTableColumn>

          <!-- 操作列 -->
          <ElTableColumn label="操作" width="120" align="center">
            <template #default="{ row }">
              <ElButton
                v-if="!row.actualReturnDate"
                type="primary"
                size="small"
                :disabled="loading"
                @click="showReturnDialog(row)"
              >
                归还图书
              </ElButton>
              <span v-else class="returned-text">已归还</span>
            </template>
          </ElTableColumn>
        </ElTable>

        <!-- 分页器 -->
        <div class="pagination-container" v-if="borrowRecords.length > 0">
          <ElPagination
            v-model:current-page="pagination.currentPage"
            v-model:page-size="pagination.pageSize"
            :page-sizes="[5, 10, 20, 50]"
            :total="pagination.total"
            layout="total, sizes, prev, pager, next, jumper"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
          />
        </div>
      </ElCard>

      <!-- 归还图书对话框 -->
      <ElDialog
        v-model="returnDialogVisible"
        title="归还图书"
        width="500px"
        :close-on-click-modal="false"
        align-center
      >
        <div class="return-dialog-content">
          <div class="book-summary">
            <img
              :src="currentReturnBook?.bookCover || '/default-book-cover.jpg'"
              :alt="currentReturnBook?.bookTitle"
              class="dialog-book-cover"
            />
            <div class="dialog-book-info">
              <h4>{{ currentReturnBook?.bookTitle }}</h4>
              <p>{{ currentReturnBook?.bookAuthor }}</p>
              <p class="borrow-date">借阅日期: {{ formatDate(currentReturnBook?.borrowDate) }}</p>
            </div>
          </div>

          <ElDivider />

          <ElForm label-width="100px">
            <ElFormItem label="归还日期" required>
              <ElDatePicker
                v-model="returnDate"
                type="date"
                value-format="YYYY-MM-DD"
                placeholder="选择归还日期"
                style="width: 100%"
                :disabled-date="(date) => date < new Date(currentReturnBook?.borrowDate)"
              />
            </ElFormItem>
          </ElForm>
        </div>

        <template #footer>
          <div class="dialog-footer">
            <ElButton @click="returnDialogVisible = false" :disabled="returnLoading">
              取消
            </ElButton>
            <ElButton type="primary" @click="handleReturn" :loading="returnLoading">
              确认归还
            </ElButton>
          </div>
        </template>
      </ElDialog>
    </div>
  </ArtTableFullScreen>
</template>

<script setup lang="ts">
  import { ref, reactive, computed, onMounted } from 'vue'
  import { ElMessage } from 'element-plus'
  import { useUserStore } from '@/store/modules/user'
  import { BorrowService } from '@/api/borrowApi'
  import { ApiStatus } from '@/utils/http/status'

  defineOptions({ name: 'PersonalRecords' })

  const userStore = useUserStore()

  // 响应式数据
  const loading = ref(false)
  const returnLoading = ref(false)
  const borrowRecords = ref<any[]>([])
  const filteredRecords = ref<any[]>([])
  const returnDialogVisible = ref(false)
  const returnDate = ref('')
  const statusFilter = ref('')
  const searchKeyword = ref('')
  const currentReturnBook = ref<any>(null)

  // 分页数据
  const pagination = reactive({
    currentPage: 1,
    pageSize: 10,
    total: 0
  })

  // 计算统计数据
  const borrowingCount = computed(() => {
    return borrowRecords.value.filter((record) => !record.actualReturnDate).length
  })

  const overdueCount = computed(() => {
    return borrowRecords.value.filter((record) => {
      if (record.actualReturnDate) return false
      if (!record.returnDate) return false
      return new Date(record.returnDate) < new Date()
    }).length
  })

  // 获取当前用户借阅记录
  const loadRecords = async () => {
    try {
      loading.value = true
      const userId = userStore.info?.userId

      if (!userId) {
        ElMessage.error('用户信息不存在，请重新登录')
        return
      }

      console.log('Loading records for user:', userId)

      const res = await BorrowService.getBorrowRecordsByUserId(userId)
      console.log('API Response:', res)

      if (res.code === ApiStatus.success) {
        // 处理单条记录或多条记录的情况
        let records = []

        if (res.data) {
          if (Array.isArray(res.data)) {
            records = res.data
          } else {
            // 如果返回的是单个对象，转换为数组
            records = [res.data]
          }
        }

        // 数据转换和扁平化
        borrowRecords.value = records.map((record: any) => {
          console.log('Processing record:', record)

          return {
            recordId: record.recordId,
            borrowId: record.borrowId || record.recordId,
            bookTitle: record.bookId?.title || record.title || '未知图书',
            bookAuthor: record.bookId?.author || record.author || '未知作者',
            bookPublisher: record.bookId?.publisher || record.publisher || '未知出版社',
            bookCategory: record.bookId?.category || record.category || '未分类',
            bookCover: record.bookId?.cover || record.cover,
            borrowDate: record.borrowDate,
            returnDate: record.returnDate,
            actualReturnDate: record.actualReturnDate,
            status: record.status,
            userId: record.user?.userId || record.userId,
            bookId: record.bookId?.bookId || record.bookId,
            // 保留原始数据
            _original: record
          }
        })

        console.log('Processed records:', borrowRecords.value)

        // 初始化过滤
        filterRecords()

        if (borrowRecords.value.length === 0) {
          ElMessage.info('暂无借阅记录')
        }
      } else {
        ElMessage.error(res.message || '获取借阅记录失败')
        borrowRecords.value = []
      }
    } catch (error) {
      console.error('Load records error:', error)
      ElMessage.error('获取借阅记录失败，请重试')
      borrowRecords.value = []
    } finally {
      loading.value = false
    }
  }

  // 过滤记录
  const filterRecords = () => {
    let filtered = [...borrowRecords.value]

    // 状态过滤
    if (statusFilter.value) {
      filtered = filtered.filter((record) => {
        const status = getRecordStatus(record)
        return status === statusFilter.value
      })
    }

    // 关键词搜索
    if (searchKeyword.value) {
      const keyword = searchKeyword.value.toLowerCase()
      filtered = filtered.filter(
        (record) =>
          record.bookTitle.toLowerCase().includes(keyword) ||
          record.bookAuthor.toLowerCase().includes(keyword)
      )
    }

    // 应用分页
    pagination.total = filtered.length
    const start = (pagination.currentPage - 1) * pagination.pageSize
    const end = start + pagination.pageSize
    filteredRecords.value = filtered.slice(start, end)
  }

  // 获取记录状态
  const getRecordStatus = (record: any) => {
    if (record.actualReturnDate) return 'returned'
    if (!record.returnDate) return 'borrowing'
    return new Date(record.returnDate) < new Date() ? 'overdue' : 'borrowing'
  }

  // 格式化日期
  const formatDate = (dateString: string | null | undefined) => {
    if (!dateString) return 'N/A'
    try {
      const date = new Date(dateString)
      if (isNaN(date.getTime())) return 'N/A'
      return date.toLocaleDateString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
      })
    } catch {
      return 'N/A'
    }
  }

  // 获取状态文本
  const getStatusText = (record: any) => {
    if (record.actualReturnDate) return '已归还'
    if (!record.returnDate) return '借阅中'
    return new Date(record.returnDate) < new Date() ? '已逾期' : '借阅中'
  }

  // 获取状态标签类型
  const getStatusTagType = (record: any) => {
    const status = getStatusText(record)
    switch (status) {
      case '已归还':
        return 'success'
      case '已逾期':
        return 'danger'
      case '借阅中':
        return 'warning'
      default:
        return 'info'
    }
  }

  // 获取状态图标
  const getStatusIcon = (record: any) => {
    const status = getStatusText(record)
    switch (status) {
      case '已归还':
        return 'el-icon-check'
      case '已逾期':
        return 'el-icon-warning'
      case '借阅中':
        return 'el-icon-time'
      default:
        return 'el-icon-info'
    }
  }

  // 显示归还对话框
  const showReturnDialog = (record: any) => {
    currentReturnBook.value = record
    returnDate.value = new Date().toISOString().split('T')[0]
    returnDialogVisible.value = true
  }

  // 执行归还操作
  const handleReturn = async () => {
    if (!returnDate.value) {
      ElMessage.error('请选择归还日期')
      return
    }

    if (!currentReturnBook.value) {
      ElMessage.error('未选择要归还的图书')
      return
    }

    try {
      returnLoading.value = true

      const borrowId = currentReturnBook.value.borrowId || currentReturnBook.value.recordId

      await BorrowService.returnBook(borrowId, {
        actualReturnDate: returnDate.value
      })

      ElMessage.success('归还成功！')
      returnDialogVisible.value = false

      // 重新加载数据
      await loadRecords()
    } catch (error) {
      console.error('Return book error:', error)
      ElMessage.error('归还失败，请重试')
    } finally {
      returnLoading.value = false
    }
  }

  // 处理图片加载错误
  const handleImageError = (event: Event) => {
    const img = event.target as HTMLImageElement
    img.src = '/default-book-cover.jpg'
  }

  // 分页处理
  const handleSizeChange = (size: number) => {
    pagination.pageSize = size
    pagination.currentPage = 1
    filterRecords()
  }

  const handleCurrentChange = (page: number) => {
    pagination.currentPage = page
    filterRecords()
  }

  // 监听过滤条件变化
  watch([statusFilter, searchKeyword], () => {
    pagination.currentPage = 1
    filterRecords()
  })

  onMounted(() => {
    loadRecords()
  })
</script>

<style lang="scss" scoped>
  .personal-records-page {
    .page-header {
      margin-bottom: 20px;

      .header-content {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 20px;

        .page-title {
          font-size: 24px;
          font-weight: 600;
          color: var(--el-text-color-primary);
          margin: 0;
        }

        .stats-cards {
          display: flex;
          gap: 16px;

          .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            min-width: 100px;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);

            &:nth-child(2) {
              background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
              box-shadow: 0 4px 12px rgba(240, 147, 251, 0.3);
            }

            &:nth-child(3) {
              background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
              box-shadow: 0 4px 12px rgba(79, 172, 254, 0.3);
            }

            .stat-number {
              font-size: 28px;
              font-weight: bold;
              margin-bottom: 8px;
            }

            .stat-label {
              font-size: 14px;
              opacity: 0.9;
            }
          }
        }
      }
    }

    .filter-card {
      margin-bottom: 20px;

      .filter-row {
        display: flex;
        gap: 16px;
        align-items: center;
        flex-wrap: wrap;
      }
    }

    .table-card {
      .book-info {
        display: flex;
        align-items: center;
        gap: 12px;

        .book-cover {
          width: 50px;
          height: 65px;
          object-fit: cover;
          border-radius: 6px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
          flex-shrink: 0;
        }

        .book-details {
          flex: 1;
          min-width: 0;

          .book-title {
            font-weight: 600;
            color: var(--el-text-color-primary);
            margin-bottom: 4px;
            word-break: break-word;
          }

          .book-meta {
            font-size: 13px;
            color: var(--el-text-color-regular);
            margin-bottom: 4px;

            .divider {
              margin: 0 6px;
              opacity: 0.5;
            }
          }

          .book-category {
            font-size: 12px;
            color: var(--el-text-color-secondary);
            background: var(--el-fill-color-light);
            padding: 2px 8px;
            border-radius: 12px;
            display: inline-block;
          }
        }
      }

      .borrow-info {
        .info-row {
          margin-bottom: 6px;
          font-size: 14px;

          &:last-child {
            margin-bottom: 0;
          }

          .label {
            color: var(--el-text-color-secondary);
            margin-right: 8px;
          }

          .value {
            color: var(--el-text-color-primary);
            font-weight: 500;
          }
        }
      }

      .returned-text {
        color: var(--el-text-color-secondary);
        font-size: 14px;
      }

      .pagination-container {
        display: flex;
        justify-content: flex-end;
        margin-top: 20px;
        padding-top: 20px;
        border-top: 1px solid var(--el-border-color-lighter);
      }
    }

    .return-dialog-content {
      .book-summary {
        display: flex;
        align-items: center;
        gap: 16px;
        padding: 16px;
        background: var(--el-fill-color-extra-light);
        border-radius: 8px;
        margin-bottom: 20px;

        .dialog-book-cover {
          width: 60px;
          height: 80px;
          object-fit: cover;
          border-radius: 6px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
          flex-shrink: 0;
        }

        .dialog-book-info {
          flex: 1;

          h4 {
            margin: 0 0 8px 0;
            color: var(--el-text-color-primary);
            font-weight: 600;
          }

          p {
            margin: 4px 0;
            color: var(--el-text-color-regular);
            font-size: 14px;

            &.borrow-date {
              color: var(--el-text-color-secondary);
              font-size: 13px;
              margin-top: 8px;
            }
          }
        }
      }
    }
  }

  // 响应式设计
  @media (max-width: 768px) {
    .personal-records-page {
      .page-header .header-content {
        flex-direction: column;
        align-items: flex-start;

        .stats-cards {
          width: 100%;
          justify-content: space-between;

          .stat-card {
            flex: 1;
            min-width: 0;
          }
        }
      }

      .filter-card .filter-row {
        flex-direction: column;
        align-items: stretch;

        .el-select,
        .el-input {
          width: 100% !important;
        }
      }
    }
  }
</style>
