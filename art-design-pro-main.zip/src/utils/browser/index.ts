/**
 * 浏览器相关工具函数统一导出
 */

export * from './bom'
export * from './cookie'
