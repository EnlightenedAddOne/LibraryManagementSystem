/**
 * 常量定义相关工具函数统一导出
 */

export * from './links'
export * from './iconfont'
